Here is a explanation of all ant brains in this folder.

Brains written by this software engineering house:
all brains in the testBrains folder
"better_example" (a modified version of "example")
"blank"
"move_ahead"
"surround"
"surround_simple"

Including Brains evolved by our genetic algorithm:
all brains which start with "ga_result"

Brains written by other software engineering houses:
all brains which start with "baxters_brain" or "lukes_brain"

Brains supplied as part of the coursework:
"example"
"sample"

Brains found at http://www.sawicki.us/icfp/2004/, the site for the 2004 ICFP Programming Contest
entry by Jeremy Sawicki (jeremy at sawicki dot us) and Mieszko Lis (elf at mieszko dot org):
all brains which start with "frictionless_bananas"


The brains given to us by other software engineering houses, and those downloaded from the sawicki site
were used for testing, and to assess the efficacy of the brains written by this house.
No part of any of these brains was incorporated into any of the brains stated as being written by this house.

However, "example", which was supplied as part of the coursework was used as the starting point for the
genetic algorithm evolution.